//
//  ServiceRequestTableViewCell.swift
//  CommuniHelp
//
//  Created by Haris Madhavan on 12/09/23.
//

import UIKit

class ServiceRequestTableViewCell: UITableViewCell {
    
    @IBOutlet weak var radioButton: UIButton!
    @IBOutlet weak var detailsLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
