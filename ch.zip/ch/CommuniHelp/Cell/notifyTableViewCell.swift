//
//  notifyTableViewCell.swift
//  CommuniHelp
//
//  Created by SAIL on 19/10/23.
//

import UIKit

class notifyTableViewCell: UITableViewCell {

    @IBOutlet weak var yesButton: UIButton!
    @IBOutlet weak var noButton: UIButton!
    @IBOutlet weak var infoLabel: UILabel!
    @IBOutlet weak var notifyTextLabel: UILabel!
    @IBOutlet weak var cellView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
