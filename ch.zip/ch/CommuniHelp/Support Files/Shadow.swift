//
//  Shadow.swift
//  CommuniHelp
//
//  Created by Haris Madhavan on 11/09/23.
//

import Foundation
import UIKit

var shadow = Shadow()

class Shadow {
    
    weak var vc1: AddProductRequestViewController?
    weak var vc2: AddMedicalRequestViewController?
    weak var vc3: AddServiceRequestViewController?
    weak var vc4: AddProductOfferViewController?
    weak var vc5: AddMedicalOfferViewController?
    weak var vc6: AddServiceOfferViewController?
    
    //Label_Shadow
    func applyShadowLabel(to label: UILabel) {
        label.layer.borderColor = UIColor.white.cgColor
        label.layer.masksToBounds = false
        label.layer.shadowColor = UIColor.black.cgColor
        label.layer.shadowOpacity = 0.3
        label.layer.shadowOffset = CGSize(width: 0, height: 4)
        label.layer.shadowRadius = 2.0
        label.backgroundColor = .white
    }
    
    //Button_Shadow
    func applyShadowButton(to button: UIButton) {
        button.layer.borderColor = UIColor.white.cgColor
        button.layer.masksToBounds = false
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOpacity = 0.3
        button.layer.shadowOffset = CGSize(width: 0, height: 4)
        button.layer.shadowRadius = 2.0
        button.backgroundColor = .white
    }
    
    //TextField_Shadow
    func applyShadowTextField(to textField: UITextField) {
        textField.layer.borderColor = UIColor.white.cgColor
        textField.layer.masksToBounds = false
        textField.layer.shadowColor = UIColor.black.cgColor
        textField.layer.shadowOpacity = 0.3
        textField.layer.shadowOffset = CGSize(width: 0, height: 4)
        textField.layer.shadowRadius = 2.0
        textField.backgroundColor = .white
    }
    
    //View_Shadow
    func applyShadowView(to view: UIView) {
        view.layer.borderColor = UIColor.white.cgColor
        view.layer.masksToBounds = false
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.3
        view.layer.shadowOffset = CGSize(width: 0, height: 4)
        view.layer.shadowRadius = 2.0
        view.backgroundColor = .white
    }
    
    func  radioButton(to button: UIButton) {
        button.layer.cornerRadius = button.frame.size.height / 2
        button.layer.borderColor = UIColor.black.cgColor
        button.layer.borderWidth = 1
        button.backgroundColor = .white
        button.setImage(UIImage(systemName: "circle.fill"), for: .normal)
        button.tintColor = .white
        button.addTarget(self, action: #selector(radioAction(_:)), for: .touchUpInside)
        button.isSelected = false
    }
    
    @objc func radioAction(_ button: UIButton) {
        vc1?.sender = button.tag
        print(vc1?.sender)
        vc2?.sender = button.tag
        print(vc2?.sender)
        vc3?.sender = button.tag
        print(vc3?.sender)
        vc4?.sender = button.tag
        print(vc4?.sender)
        vc5?.sender = button.tag
        print(vc5?.sender)
        vc6?.sender = button.tag
        print(vc6?.sender)
        
        button.isSelected = !button.isSelected
        
        if button.isSelected == true{
            button.setImage(UIImage(systemName: "checkmark.circle.fill"), for: .normal)
            button.tintColor = .blue
        } else {
            button.setImage(UIImage(systemName: "circle.fill"), for: .normal)
            button.tintColor = .white
        }
    }
}
