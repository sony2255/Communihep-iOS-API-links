//
//  Constant.swift
//  WeatherApp
//
//  Created by MAC-Air on 08/09/23.
//

import Foundation
import UIKit

//public class Constants {
//    
//    enum serviceType: String {
//        
//        case ipAddress = "http://192.168.116.23//"
//        case loginURl = "ems1/login.php?"
//        case productOffers = "ems1/productoffer.php?"
//        case productRequest = "http://192.168.254.23/ems1/productrequest.php"
//        case accecptPrdOffer = "ems1/acceptproductoff.php?"
//        case medicalOffers = "http://192.168.254.23/ems1/medicaloffer.php"
//        case medicalRequest = "http://192.168.254.23/ems1/medicalrequest.php"
//        case serviceOffers = "http://192.168.254.23/ems1/serviceoffer.php"
//        case serviceRequest = "http://192.168.254.23/ems1/servicerequest.php"
//        case mycommunityOffers = "http://192.168.254.23/ems1/mycommunityoffer.php?id=1"
//        case mycommunityRequest = "http://192.168.254.23/ems1/mycommunityrequest.php?id=1"
//       
//    }
//    
//    static let ipUrl: serviceType =  .ipAddress
//    static let loginUrl: serviceType = .loginURl
//    static let prdOfferUrl: serviceType = .productOffers
//    static let acptPrdOfferUrl : serviceType = .accecptPrdOffer
//    
//    
//}
		
struct ServiceAPI {
    
    static let baseURL = "http://192.168.116.23//"
    static let signUp = baseURL+"ems1/signup.php?" // FormData Params Key & Values username=aadya&phone_number=5656565656&email=aadya@gmail.com&pass=aad
    static let loginURl = baseURL+"ems1/login.php?" // FormData Params Key & Valuesemail=aadya@gmail.com&pass=aad
    static let productOffers = baseURL+"ems1/productoffer.php?"
    static let productRequest = baseURL+"ems1/productrequest.php?"
    static let medicalOffers = baseURL+"ems1/medicaloffer.php?"
    static let medicalRequests = baseURL+"ems1/medicalrequest.php?"
    static let serviceOffers = baseURL+"ems1/serviceoffer.php?"
    static let serviceRequests = baseURL+"ems1/servicerequest.php?"
    static let myCommunityOffers = baseURL+"ems1/mycommunityoffer.php?"
    // FormData Params Key & Values user_id=1
    static let myCommunityRequests = baseURL+"ems1/mycommunityrequest.php?"
    // FormData Params Key & Values user_id=1
    static let profile = baseURL+"ems1/profile.php?" // FormData Params Key & Values user_id=15
    static let acceptAPI = baseURL+"ems1/accept.php?" // FormData Params Key & Values user_id=15&id=53
    static let proceedAPI = baseURL+"ems1/proceed.php?" // FormData Params Key & Values user_id=15&id=53
    static let ignoreAPI = baseURL+"ems1/ignore.php?" // FormData Params Key & Values user_id=15&id=53
    static let deleteAPI = baseURL+"ems1/delete.php?" // FormData Params Key & Values user_id=15&id=53
    static let myHistoryOffers = baseURL+"ems1/myhistoryoffer.php?"
    // FormData Params Key & Values user_id=1
    static let myHistoryRequests = baseURL+"ems1/myhistoryrequest.php?"
    // FormData Params Key & Values user_id=1
    static let addProductOffer = baseURL+"ems1/addofferproduct.php?"
    // FormData Params Key & Values user_id=15&category=carpenter&details=need%20chairs
    static let addMedicalOffer = baseURL+"ems1/addoffermedical.php?"
    // FormData Params Key & Values user_id=15&category=carpenter&details=need%20chairs
    static let addServiceOffer = baseURL+"ems1/addofferservice.php?"
    // FormData Params Key & Values user_id=15&category=carpenter&details=need%20chairs
    static let addProductRequest = baseURL+"ems1/addrequestproduct.php?"
    // FormData Params Key & Values user_id=15&category=carpenter&details=need%20chairs
    static let addMedicalRequest = baseURL+"ems1/addrequestmedical.php?"
    // FormData Params Key & Values user_id=15&category=carpenter&details=need%20chairs
    static let addServiceRequest = baseURL+"ems1/addrequestservice.php?"
    // FormData Params Key & Values user_id=15&category=carpenter&details=need%20chairs
    static let notify1 = baseURL+"ems1/notify1.php?"// FormData Params Key & Values user_id=1
    static let notify2 = baseURL+"ems1/notify2.php?"// FormData Params Key & Values user_id=1
    static let yesAPI = baseURL+"ems1/yes.php?" // FormData Params Key & Values id=53
    static let noAPI = baseURL+"ems1/no.php?" // FormData Params Key & Values id=53
    static let editProfile = baseURL+"ems1/editprofile.php?"
    // FormData Params Key & Values user_id=15&username=aadya&phone_number=5656565656&email=aadya@gmail.com
    static let changePass = baseURL+"ems1/changepassword.php?"
    // FormData Params Key & Values user_id=15&oldpass=shyam&newpass=syam
    static let addReview = baseURL+"ems1/addreview.php?"
    // FormData Params Key & Values ref_id=80&category=clothes&details=shirts&user_id=8&review=average
    static let viewReview = baseURL+"ems1/viewreview.php?"
    // FormData Params Key & Values user_id=8
    static let emailUrl = baseURL+"ems1/checkmail.php"
    
    
    
//    var refID : String? {
//        UserDefaultsManager.shared.getUserRefId()
//    }
//    var userID : String? {
//        UserDefaultsManager.shared.getUserId()
//    }
//
//    static var ipAddress = "http://192.168.254.23//"
//
//    static var signUp = ipAddress+"ems1/signup.php?"
//    // FormData Params Key & Values username=aadya&phone_number=5656565656&email=aadya@gmail.com&pass=aad
////    static var signUp : String {
////        if let regId = ServiceAPI().refID {
////            return ipAddress+"ems1/signup.php?" // FormData Params Key & Values user_id=15&id=53
////        } else {
////            return ""
////        }
////    }
//    static var loginURl = ipAddress+"ems1/login.php?" // FormData Params Key & Valuesemail=aadya@gmail.com&pass=aad
//    static var productOffers = ipAddress+"ems1/productoffer.php?"
//    static var productRequest = ipAddress+"ems1/productrequest.php?"
//    static var medicalOffers = ipAddress+"ems1/medicaloffer.php?"
//    static var medicalRequests = ipAddress+"ems1/medicalrequest.php?"
//    static var serviceOffers = ipAddress+"ems1/serviceoffer.php?"
//    static var serviceRequests = ipAddress+"ems1/servicerequest.php?"
////    static var myCommunityOffers = ipAddress+"ems1/mycommunityoffer.php?"
//    // FormData Params Key & Values user_id=1
//    //static var myCommunityRequests = ipAddress+"ems1/mycommunityrequest.php?"
//    // FormData Params Key & Values user_id=1
//    static var profile : String {
//        if let userId = ServiceAPI().userID {
//            return ipAddress+"ems1/profile.php?user_id=\(userId)" // FormData Params Key & Values user_id=15
//        } else {
//            return ""
//        }
//    }
//    static var myCommunityOffers : String {
//        if let userId = ServiceAPI().userID {
//            return ipAddress+"ems1/mycommunityoffer.php?user_id=\(userId)" // FormData Params Key & Values user_id=1
//        } else {
//            return ""
//        }
//    }
//    static var myCommunityRequests : String {
//        if let userId = ServiceAPI().userID {
//            return ipAddress+"ems1/mycommunityrequest.php?user_id=\(userId)" // FormData Params Key & Values user_id=1
//        } else {
//            return ""
//        }
//    }
//    static var acceptAPI : String {
//        if let regId = ServiceAPI().refID {
//            return ipAddress+"ems1/accept.php?" // FormData Params Key & Values user_id=15&id=53
//        } else {
//            return ""
//        }
//    }
//    static var proceedAPI : String {
//        if let regId = ServiceAPI().refID{
//            return ipAddress+"ems1/proceed.php?" // FormData Params Key & Values user_id=15&id=53
//        } else {
//            return ""
//        }
//    }
//    static var ignoreAPI : String {
//        if let regId = ServiceAPI().refID {
//            return ipAddress+"ems1/ignore.php?" // FormData Params Key & Values user_id=15&id=53
//        } else {
//            return ""
//        }
//    }
//    static var deleteAPI : String {
//        if let regId = ServiceAPI().refID {
//            return ipAddress+"ems1/delete.php?" // FormData Params Key & Values user_id=15&id=53
//        } else {
//            return ""
//        }
//    }
//    //static var proceedAPI = ipAddress+"ems1/proceed.php?" // FormData Params Key & Values id=53
//    //static var ignoreAPI = ipAddress+"ems1/ignore.php?" // FormData Params Key & Values id=53
//    static var myHistoryOffers : String {
//        if let userId = ServiceAPI().userID {
//            return ipAddress+"ems1/myhistoryoffer.php?user_id=\(userId)" // FormData Params Key & Values user_id=1
//        } else {
//            return ""
//        }
//    }
//    static var myHistoryRequests : String {
//        if let userId = ServiceAPI().userID {
//            return ipAddress+"ems1/myhistoryrequest.php?user_id=\(userId)" // FormData Params Key & Values user_id=1
//        } else {
//            return ""
//        }
//    }
//    //static var myHistoryOffers = ipAddress+"ems1/myhistoryoffer.php?"
//    // FormData Params Key & Values user_id=1
//    static var addProductOffer = ipAddress+"ems1/addofferproduct.php?"
//    // FormData Params Key & Values user_id=15&category=carpenter&details=need%20chairs
//    static var addMedicalOffer = ipAddress+"ems1/addoffermedical.php?"
//    // FormData Params Key & Values user_id=15&category=carpenter&details=need%20chairs
//    static var addServiceOffer = ipAddress+"ems1/addofferservice.php?"
//    // FormData Params Key & Values user_id=15&category=carpenter&details=need%20chairs
//    //static var myHistoryRequests = ipAddress+"ems1/myhistoryrequest.php?"
//    // FormData Params Key & Values user_id=1
//    static var addProductRequest = ipAddress+"ems1/addrequestproduct.php?"
//    // FormData Params Key & Values user_id=15&category=carpenter&details=need%20chairs
//    static var addMedicalRequest = ipAddress+"ems1/addrequestmedical.php?"
//    // FormData Params Key & Values user_id=15&category=carpenter&details=need%20chairs
//    static var addServiceRequest = ipAddress+"ems1/addrequestservice.php?"
//    // FormData Params Key & Values user_id=15&category=carpenter&details=need%20chairs
//    //static var deleteAPI = ipAddress+"ems1/delete.php?" // FormData Params Key & Values id=53
//    //static var notify1 = ipAddress+"ems1/notify1.php?"
//    // FormData Params Key & Values user_id=1
//    static var notify1 : String {
//        if let userId = ServiceAPI().userID {
//            return ipAddress+"ems1/notify1.php?user_id=\(userId)" // FormData Params Key & Values user_id=1
//        } else {
//            return ""
//        }
//    }
//    //static var notify2 = ipAddress+"ems1/notify2.php?"
//    // FormData Params Key & Values user_id=1
//    static var notify2 : String {
//        if let userId = ServiceAPI().userID {
//            return ipAddress+"ems1/notify2.php?user_id=\(userId)" // FormData Params Key & Values user_id=1
//        } else {
//            return ""
//        }
//    }
//    //static var yesAPI = ipAddress+"ems1/yes.php?" // FormData Params Key & Values id=53
//   // static var noAPI = ipAddress+"ems1/no.php?" // FormData Params Key & Values id=53
//    static var yesAPI : String {
//        if let refId = ServiceAPI().refID{
//            return ipAddress+"ems1/yes.php?" // FormData Params Key & Values user_id=15&id=53
//        } else {
//            return ""
//        }
//    }
//    static var noAPI : String {
//        if let refId = ServiceAPI().refID {
//            return ipAddress+"ems1/no.php?ref_id=\(refId)" // FormData Params Key & Values user_id=15&id=53
//        } else {
//            return ""
//        }
//    }
//    static var editProfile = ipAddress+"ems1/editprofile.php?"
//    // FormData Params Key & Values user_id=15&username=aadya&phone_number=5656565656&email=aadya@gmail.com
//    static var changePass = ipAddress+"ems1/changepassword.php?"
//    // FormData Params Key & Values user_id=15&oldpass=shyam&newpass=syam

		
}

//import Foundation
//import UIKit
//
//struct ServiceAPI {
//    
//    static let baseURL = "http://192.168.254.23//"
//    static let loginURL = baseURL+"trspt1/signup.php?" // FormData Params Key & Values username=aadya&phone_number=5656565656&email=aadya@gmail.com&pass=aad
//    static let loginURl = baseURL+"ems1/login.php?" // FormData Params Key & Valuesemail=aadya@gmail.com&pass=aad
//    static let productOffers = baseURL+"ems1/productoffer.php?"
//    static let productRequest = baseURL+"ems1/productrequest.php?"
//    static let medicalOffers = baseURL+"ems1/medicaloffer.php?"
//    static let medicalRequests = baseURL+"ems1/medicalrequest.php?"
//    static let serviceOffers = baseURL+"ems1/serviceoffer.php?"
//    static let serviceRequests = baseURL+"ems1/servicerequest.php?"
//    static let myCommunityOffers = baseURL+"ems1/mycommunityoffer.php?"
//    // FormData Params Key & Values user_id=1
//    static let myCommunityRequests = baseURL+"ems1/mycommunityrequest.php?"
//    // FormData Params Key & Values user_id=1
//    static let profile = baseURL+"ems1/profile.php?" // FormData Params Key & Values user_id=15
//    static let acceptAPI = baseURL+"ems1/accept.php?" // FormData Params Key & Values user_id=15&id=53
//    static let proceedAPI = baseURL+"ems1/proceed.php?" // FormData Params Key & Values user_id=15&id=53
//    static let ignoreAPI = baseURL+"ems1/ignore.php?" // FormData Params Key & Values user_id=15&id=53
//    static let deleteAPI = baseURL+"ems1/delete.php?" // FormData Params Key & Values user_id=15&id=53
//    static let myHistoryOffers = baseURL+"ems1/myhistoryoffer.php?"
//    // FormData Params Key & Values user_id=1
//    static let myHistoryRequests = baseURL+"ems1/myhistoryrequest.php?"
//    // FormData Params Key & Values user_id=1
//    static let addProductOffer = baseURL+"ems1/addofferproduct.php?"
//    // FormData Params Key & Values user_id=15&category=carpenter&details=need%20chairs
//    static let addMedicalOffer = baseURL+"ems1/addoffermedical.php?"
//    // FormData Params Key & Values user_id=15&category=carpenter&details=need%20chairs
//    static let addServiceOffer = baseURL+"ems1/addofferservice.php?"
//    // FormData Params Key & Values user_id=15&category=carpenter&details=need%20chairs
//    static let addProductRequest = baseURL+"ems1/addrequestproduct.php?"
//    // FormData Params Key & Values user_id=15&category=carpenter&details=need%20chairs
//    static let addMedicalRequest = baseURL+"ems1/addrequestmedical.php?"
//    // FormData Params Key & Values user_id=15&category=carpenter&details=need%20chairs
//    static let addServiceRequest = baseURL+"ems1/addrequestservice.php?"
//    // FormData Params Key & Values user_id=15&category=carpenter&details=need%20chairs
//    static let notify1 = baseURL+"ems1/notify1.php?"// FormData Params Key & Values user_id=1
//    static let notify2 = baseURL+"ems1/notify2.php?"// FormData Params Key & Values user_id=1
//    static let yesAPI = baseURL+"ems1/yes.php?" // FormData Params Key & Values id=53
//    static let noAPI = baseURL+"ems1/no.php?" // FormData Params Key & Values id=53
//    static let editProfile = baseURL+"ems1/editprofile.php?"
//    // FormData Params Key & Values user_id=15&username=aadya&phone_number=5656565656&email=aadya@gmail.com
//    static let changePass = baseURL+"ems1/changepassword.php?"
//    // FormData Params Key & Values user_id=15&oldpass=shyam&newpass=syam
//
//}
