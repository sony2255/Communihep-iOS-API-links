//
//  editProfileModel.swift
//  CommuniHelp
//
//  Created by SAIL on 19/10/23.
//

import Foundation

// MARK: - Welcome
struct editProfileModel: Codable {
    var status: Bool?
    var message: String?
}

