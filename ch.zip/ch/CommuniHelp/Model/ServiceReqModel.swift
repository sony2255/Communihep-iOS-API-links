//
//  ServiceReqModel.swift
//  CommuniHelp
//
//  Created by SAIL on 10/10/23.
//

import Foundation

// MARK: - Welcome
struct ServiceRequests: Codable {
    var status: Bool?
    var message: String?
    var data: [ServiceReqData]?
}

// MARK: - Datum
struct ServiceReqData: Codable {
    var refID, userID, category, details: String?

    enum CodingKeys: String, CodingKey {
        case refID = "ref_id"
        case userID = "user_id"
        case category, details
    }
}
