//
//  LoginModel.swift
//  CommuniHelp
//
//  Created by SAIL on 09/10/23.
//

import Foundation

// MARK: - Welcome
struct LoginJSON: Codable {
    var status: Bool?
    var message: String?
    var data: DataClass?
}

// MARK: - DataClass
struct DataClass: Codable {
    var userID, username, email, phoneNumber: String?
    var pass: String?

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case username, email
        case phoneNumber = "phone_number"
        case pass
    }
}

