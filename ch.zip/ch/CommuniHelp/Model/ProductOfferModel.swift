//
//  ProductOfferModel.swift
//  CommuniHelp
//
//  Created by SAIL on 09/10/23.
//

import Foundation

// MARK: - Welcome
struct ProductOffers: Codable {
    var status: Bool?
    var message: String?
    var data: [productData]?
}

// MARK: - Datum
struct productData: Codable {
    var refID, userID, category, details: String?

    enum CodingKeys: String, CodingKey {
        case refID = "ref_id"
        case userID = "user_id"
        case category, details
    }
}

