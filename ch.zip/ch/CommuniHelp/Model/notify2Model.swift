//
//  notify2Model.swift
//  CommuniHelp
//
//  Created by SAIL on 19/10/23.

import Foundation

// MARK: - Welcome
struct notify2Model: Codable {
    var status: Bool?
    var message: String?
    var data: [notify2Data]?
}

// MARK: - Datum
struct notify2Data: Codable {
    var refID, userID, category, details: String?
    var phoneNumber: String?

    enum CodingKeys: String, CodingKey {
        case refID = "ref_id"
        case userID = "user_id"
        case category, details
        case phoneNumber = "phone_number"
    }
}

