//
//  changePasswordModel.swift
//  CommuniHelp
//
//  Created by SAIL on 19/10/23.

import Foundation

// MARK: - Welcome
struct changePass: Codable {
    var status: Bool?
    var message: String?
}
