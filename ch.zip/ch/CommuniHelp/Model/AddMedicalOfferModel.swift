//
//  AddMedicalOfferModel.swift
//  CommuniHelp
//
//  Created by SAIL on 18/10/23.
//

import Foundation

// MARK: - Welcome
struct AddMedicaOff : Codable {
    var status: Bool?
    var message: String?
}
