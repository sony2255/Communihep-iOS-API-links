//
//  viewReviewModel.swift
//  CommuniHelp
//
//  Created by SAIL on 16/11/23.
//

// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)

import Foundation

// MARK: - Welcome
struct viewReviewModel: Codable {
    var status: Bool?
    var message: String?
    var data: [Datum]?
}

// MARK: - Datum
struct Datum: Codable {
    var refID, userID, category, details: String?
    var review: String?

    enum CodingKeys: String, CodingKey {
        case refID = "ref_id"
        case userID = "user_id"
        case category, details, review
    }
}
