//
//  profileModel.swift
//  CommuniHelp
//
//  Created by SAIL on 19/10/23.
//

import Foundation

// MARK: - Welcome
struct profileModel: Codable {
    var status: Bool?
    var message: String?
    var data: profileData?
}

// MARK: - DataClass
struct profileData: Codable {
    var userID, username, email, phoneNumber: String?
    var pass: String?

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case username, email
        case phoneNumber = "phone_number"
        case pass
    }
}
