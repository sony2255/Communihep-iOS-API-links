//
//  HomeServiceViewController.swift
//  CommuniHelp
//
//  Created by Haris Madhavan on 12/09/23.
//

import UIKit

class HomeServiceViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var segmentControl: UISegmentedControl!
    @IBOutlet weak var homeServiceTableView: UITableView!
    
    var nSelectedSegmentIndex: Int = 1
    var offers: ServiceOffer!
    var requests: ServiceRequests!
    var communityOffer: MycommunityOffer!
    
    let UserID : String = UserDefaultsManager.shared.getUserId() ?? ""
    var RefID = String()
        
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.topView.layer.cornerRadius = 35
        self.topView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        
        self.homeServiceTableView.delegate = self
        self.homeServiceTableView.dataSource = self
        
        self.GetServiceAPI()
        
    }
    override func viewWillAppear(_ animated: Bool) {
//        GetServiceAPI()
//        GetServiceReqAPI()
    }
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func segmentControlAction(_ sender: Any) {
        switch segmentControl.selectedSegmentIndex {
        case 0:
            self.nSelectedSegmentIndex = 1
            self.GetServiceAPI()
        case 1:
            self.nSelectedSegmentIndex = 2
            self.GetServiceReqAPI()
        default:
            self.GetServiceAPI()
        }
//        if (sender as AnyObject).selectedSegmentIndex == 0 {
//            self.nSelectedSegmentIndex = 1
//        }
//        else {
//            self.nSelectedSegmentIndex = 2
//        }
//        self.homeServiceTableView.reloadData()
    }
    
    
    func GetServiceAPI() {
//        APIHandler().getAPIValues(type: ServiceOffer.self, apiUrl: ServiceAPI.serviceOffers, method: "GET")
        APIHandler().getAPIValues(type: ServiceOffer.self, apiUrl: "\(ServiceAPI.serviceOffers)", method: "GET")
        { result in
            switch result {
            case .success(let data):
                self.offers = data
                print(self.offers.data ?? "")
                print(self.offers.data?.count ?? 0)
                print(self.offers.data?.first?.refID ?? "")
                DispatchQueue.main.async {
                    UserDefaultsManager.shared.saveRefId(self.offers.data?.first?.refID ?? "")
                    self.RefID = UserDefaultsManager.shared.getUserRefId() ?? ""
                    //                    UserDefaultsManager.shared.saveUserId(self.offers.data?.first?.userID ?? "")
                    
                    self.homeServiceTableView.reloadData()
                }
            case.failure(let error):
                print(error)
            }
        }
    }
    
    func GetServiceReqAPI() {
//        APIHandler().getAPIValues(type: ServiceRequests.self, apiUrl: ServiceAPI.serviceRequests, method: "GET")
        APIHandler().getAPIValues(type: ServiceRequests.self, apiUrl: "\(ServiceAPI.serviceRequests)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.requests = data
                print(self.requests.data ?? "")
                print(self.requests.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.RefID = self.requests.data?.first?.refID ?? ""
                    UserDefaultsManager.shared.saveRefId(self.RefID)
                    self.homeServiceTableView.reloadData()
                }
            case.failure(let error):
                print(error)
            }
        }
    }
}

extension HomeServiceViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if nSelectedSegmentIndex == 1 {
            return self.offers?.data?.count ?? 1
        }
        else {
            return self.requests?.data?.count ?? 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HomeServiceTableViewCell", for: indexPath) as! HomeServiceTableViewCell
        
        cell.cellView.layer.cornerRadius = 10
        shadow.applyShadowView(to: cell.cellView)
        
        cell.acceptButton.tag = indexPath.row
        cell.acceptButton.addTarget(self, action: #selector(acceptOfferAPI), for: .touchUpInside)
        
        cell.reviewButton.tag = indexPath.row
        cell.reviewButton.addTarget(self, action: #selector(reviewAction), for: .touchUpInside)
        
        if nSelectedSegmentIndex == 1 {
            if let offer = self.offers?.data?[indexPath.row] {
                cell.infoLabel.text = "\(offer.userID ?? "") : \(offer.category ?? "")\n\(offer.details ?? "")"
            } else {
                cell.infoLabel.text = "No Data"
            }
        } else if nSelectedSegmentIndex == 2 {
            if let request = self.requests?.data?[indexPath.row] {
                cell.infoLabel.text = "\(request.userID ?? "") : \(request.category ?? "")\n\(request.details ?? "")"
            } else {
                cell.infoLabel.text = "No Data"
            }
        }

//        cell.deleteButton.titleLabel?.font = .systemFont(ofSize: 12)
//        
//        if nSelectedSegmentIndex == 1 {
//            if let offer = self.offers?.data?[indexPath.row] {
//                cell.infoLabel.text = "\(offer.userID ?? "") : \(offer.category ?? "")\n\(offer.details ?? "")"
//            } else {
//                cell.infoLabel.text = "Nil"
//            }
//        } else {
//            if let request = self.requests?.data?[indexPath.row] {
//                cell.infoLabel.text = "\(request.userID ?? "") : \(request.category ?? "")\n\(request.details ?? "")"
//            } else {
//                cell.infoLabel.text = "Nil"
//            }
//        }

        
        return cell
    }
    
    @objc func reviewAction(sender: UIButton){
        let rowToRemove = sender.tag
        var refID: String? // Initialize refID as an optional String
            
            if self.nSelectedSegmentIndex == 1 {
                // Check if there's an offerRefID at the specified rowToRemove
                if let offerRefID = self.offers?.data?[rowToRemove].userID {
                    refID = offerRefID
                    UserDefaultsManager.shared.saveUserId(refID ?? "")
                    let vc = UIStoryboard(name: "HomeStoryboard", bundle: nil).instantiateViewController(withIdentifier: "ViewReviewViewController") as! ViewReviewViewController
                    navigationController?.pushViewController(vc, animated: true)
                }
            } else if self.nSelectedSegmentIndex == 2 {
                // Check if there's a requestRefID at the specified rowToRemove
                if let requestRefID = self.requests?.data?[rowToRemove].userID {
                    refID = requestRefID
                    UserDefaultsManager.shared.saveUserId(refID ?? "")
                    let vc = UIStoryboard(name: "HomeStoryboard", bundle: nil).instantiateViewController(withIdentifier: "ViewReviewViewController") as! ViewReviewViewController
                    navigationController?.pushViewController(vc, animated: true)
                }
            }
            
            self.homeServiceTableView.reloadData()
    }
    
    @objc func acceptOfferAPI(sender: UIButton) {
        let rowToRemove = sender.tag
        var refID: String? // Initialize refID as an optional String
            
            if self.nSelectedSegmentIndex == 1 {
                // Check if there's an offerRefID at the specified rowToRemove
                if let offerRefID = self.offers?.data?[rowToRemove].refID {
                    refID = offerRefID
                }
            } else if self.nSelectedSegmentIndex == 2 {
                // Check if there's a requestRefID at the specified rowToRemove
                if let requestRefID = self.requests?.data?[rowToRemove].refID {
                    refID = requestRefID
                }
            }
            
            guard let validRefID = refID else {
                // Ensure that a valid refID exists for the selected segment
                return
            }
            
            if self.nSelectedSegmentIndex == 1 {
                // Use the selected refID to find the index to remove from "offers" data
                if let indexToRemove = self.offers?.data?.firstIndex(where: { $0.refID == validRefID }) {
                    self.offers?.data?.remove(at: indexToRemove)
                }
            } else if self.nSelectedSegmentIndex == 2 {
                // Use the selected refID to find the index to remove from "requests" data
                if let indexToRemove = self.requests?.data?.firstIndex(where: { $0.refID == validRefID }) {
                    self.requests?.data?.remove(at: indexToRemove)
                }
            }
            
            self.homeServiceTableView.reloadData()
            
        let formData: [String: String] = ["user_id": self.UserID, "id": validRefID]
        
        APIHandler().postAPIValues(type: AcceptModel.self, apiUrl: "\(ServiceAPI.acceptAPI)", method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status)")
                print("Message: \(response.message)")
                DispatchQueue.main.async {
                    self.GetServiceAPI()
                    self.GetServiceReqAPI()
                }
            case .failure(let error):
                print("Error: \(error)")
                // Handle error
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
}
