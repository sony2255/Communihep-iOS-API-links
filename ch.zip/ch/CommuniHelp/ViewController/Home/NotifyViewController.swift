//
//  notifyViewController.swift
//  CommuniHelp
//
//  Created by SAIL on 19/10/23.
//

import UIKit

class notifyViewController: UIViewController {
    
    @IBOutlet weak var segmentControl: UISegmentedControl!
    @IBOutlet weak var notifyTableView: UITableView!
    @IBOutlet weak var topView: UIView!
    
    var offers: notify1Model!
    var requests: notify2Model!
    var nSelectedSegmentIndex : Int = 1
    
    let userid = UserDefaultsManager.shared.getUserId() ?? ""
    let refid = UserDefaultsManager.shared.getUserRefId() ?? ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.topView.layer.cornerRadius = 35
        self.topView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        
        self.notifyTableView.delegate = self
        self.notifyTableView.dataSource = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        GetNotify1API()
        GetNotify2API()
    }
    
    @IBAction func segmentControlAction(_ sender: Any) {
        if (sender as AnyObject).selectedSegmentIndex == 0 {
                self.nSelectedSegmentIndex = 1
            }
            else {
                self.nSelectedSegmentIndex = 2
            }
            self.notifyTableView.reloadData()
    }
    
//    @IBOutlet weak var backActionButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//    }
    @IBAction func backActionButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    //@IBOutlet weak var backActionButton: UILabel!
    func GetNotify1API() {
//        APIHandler().getAPIValues(type: notify1Model.self, apiUrl: ServiceAPI.notify1, method: "GET")
        APIHandler().getAPIValues(type: notify1Model.self, apiUrl: "\(ServiceAPI.notify1)user_id=\(userid)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.offers = data
                print(self.offers.data ?? "")
                print(self.offers.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.notifyTableView.reloadData()
                }
            case.failure(let error):
                print(error)
            }
        }
    }
    
    func GetNotify2API() {
//        APIHandler().getAPIValues(type: notify2Model.self, apiUrl: ServiceAPI.notify2, method: "GET")
        APIHandler().getAPIValues(type: notify2Model.self, apiUrl: "\(ServiceAPI.notify2)user_id=\(userid)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.requests = data
                print(self.requests.data ?? "")
                print(self.requests.data?.count ?? 0)
                DispatchQueue.main.async {
                    UserDefaultsManager.shared.saveUserId(self.requests.data?.first?.userID ?? "")
                    UserDefaultsManager.shared.saveRefId(self.requests.data?.first?.refID ?? "")
                    UserDefaultsManager.shared.saveDetails(self.requests.data?.first?.details ?? "")
                    UserDefaultsManager.shared.saveCategory(self.requests.data?.first?.category ?? "")
                    self.notifyTableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
}
extension notifyViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if nSelectedSegmentIndex == 1 {
            return self.offers?.data?.count ?? 1
        }
        else {
            return self.requests?.data?.count ?? 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "notifyTableViewCell", for: indexPath) as! notifyTableViewCell
        
        cell.cellView.layer.cornerRadius = 10
        shadow.applyShadowView(to: cell.cellView)
        
        cell.yesButton.tag = indexPath.row
        cell.yesButton.addTarget(self, action: #selector(yesAPI), for: .touchUpInside)
        
        cell.noButton.tag = indexPath.row
        cell.noButton.addTarget(self, action: #selector(noAPI), for: .touchUpInside)
        
        if nSelectedSegmentIndex == 1 {
            cell.yesButton.isHidden = false
            cell.noButton.isHidden = false
            cell.yesButton.setTitle("Yes", for: .normal)
            cell.yesButton.setTitleColor(.green, for: .normal)
            cell.noButton.setTitle("No", for: .normal)
            cell.noButton.setTitleColor(.red, for: .normal)
            if let offer = self.offers?.data?[indexPath.row] {
                cell.infoLabel.text = "\(offer.userID ?? "") : \(offer.category ?? "")\n\(offer.details ?? "")"
                cell.notifyTextLabel.text = "Your offer/request is proceeded... Please click yes to share your contact..."
            } else {
                cell.infoLabel.text = "No Data"
                cell.notifyTextLabel.text = ""
            }
        } else {
            cell.yesButton.isHidden = true
            cell.noButton.isHidden = false
            cell.noButton.setTitle("Add Review", for: .normal)
            cell.noButton.setTitleColor(.blue, for: .normal)
            cell.noButton.tag = indexPath.row
            cell.noButton.addTarget(self, action: #selector(reviewAPI), for: .touchUpInside)
            if let request = self.requests?.data?[indexPath.row] {
                cell.infoLabel.text = "\(request.userID ?? "") : \(request.category ?? "")\n\(request.details ?? "")"
                cell.notifyTextLabel.text = "You have received the contact info... \nPhone NO : \(request.phoneNumber ?? "")"
            } else {
                cell.infoLabel.text = "No Data"
                cell.notifyTextLabel.text = ""
            }
        }
        
        cell.yesButton.titleLabel?.font = .systemFont(ofSize: 12)
        cell.noButton.titleLabel?.font = .systemFont(ofSize: 12)
        
        return cell
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    @objc func yesAPI(sender: UIButton) {
        let rowToRemove = sender.tag
        
        guard let refID = self.offers?.data?[rowToRemove].refID else {
            return
        }
        if let indexToRemove = self.offers?.data?.firstIndex(where: {$0.refID == refID}) {
            self.offers?.data?.remove(at: indexToRemove)
            GetNotify1API()
        }
        self.notifyTableView.reloadData()
        
        let formData: [String: String] = [ "ref_id": refID]
        
        APIHandler().postAPIValues(type: yesModel.self, apiUrl: "\(ServiceAPI.yesAPI)", method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status)")
                print("Message: \(response.message)")
                DispatchQueue.main.async {
                    self.GetNotify1API()
                }
            case .failure(let error):
                print("Error: \(error)")
                // Handle error
            }
        }
    }
    
    @objc func noAPI(sender: UIButton) {
        let rowToRemove = sender.tag
        guard let refID = self.offers?.data?[rowToRemove].refID else {
            return
        }
        if let indexToRemove = self.offers?.data?.firstIndex(where: {$0.refID == refID}) {
            self.offers?.data?.remove(at: indexToRemove)
            GetNotify1API()
        }
            self.notifyTableView.reloadData()
            
            let formData: [String: String] = [ "ref_id": refID]
            
            APIHandler().postAPIValues(type: noModel.self, apiUrl: "\(ServiceAPI.noAPI)", method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print("Status: \(response.status)")
                    print("Message: \(response.message)")
                    DispatchQueue.main.async {
                        self.GetNotify1API()
                    }
                case .failure(let error):
                    print("Error: \(error)")
                    // Handle error
                }
            }
        }
    
    @objc func reviewAPI(sender: UIButton) {
        let storyboard = UIStoryboard(name: "HomeStoryboard", bundle: nil).instantiateViewController(withIdentifier: "ReviewViewController") as! ReviewViewController
        navigationController?.pushViewController(storyboard, animated: true)
        
    }
        
    }

