//
//  EmergencyViewController.swift
//  CommuniHelp
//
//  Created by Haris Madhavan on 11/09/23.
//

import UIKit

class EmergencyViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var segmentControl: UISegmentedControl!
    @IBOutlet weak var emergencyTableView: UITableView!
    
    var nSelectedSegmentIndex: Int = 1
    var offers: MedicalOffer!
    var requests: MedicalRequests!
    var communityOffer: MycommunityOffer!
    
    let UserID : String = UserDefaultsManager.shared.getUserId() ?? ""
    //let RefID : String = UserDefaultsManager.shared.getUserRefId() ?? ""
    var RefID = String()
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.topView.layer.cornerRadius = 35
        self.topView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        
        self.emergencyTableView.delegate = self
        self.emergencyTableView.dataSource = self
        self.GetMedicalAPI()
        //        shadow.applyShadowLabel(to: requestLabel)
    }
    override func viewWillAppear(_ animated: Bool) {
        //GetMedicalAPI()
       // GetMedicalReqAPI()
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func segmentControlAction(_ sender: Any) {
        switch segmentControl.selectedSegmentIndex {
        case 0:
            self.nSelectedSegmentIndex = 1
            self.GetMedicalAPI()
        case 1:
            self.nSelectedSegmentIndex = 2
            self.GetMedicalReqAPI()
        default:
            self.GetMedicalAPI()
        }
        
//        if (sender as AnyObject).selectedSegmentIndex == 0 {
//            self.nSelectedSegmentIndex = 1
//            self.emergencyTableView.reloadData()
//        }
//        else {
//            self.nSelectedSegmentIndex = 2
//            self.emergencyTableView.reloadData()
//        }
        //self.emergencyTableView.reloadData()
    }
    
    func GetMedicalAPI() {
//        APIHandler().getAPIValues(type: MedicalOffer.self, apiUrl: ServiceAPI.medicalOffers, method: "GET")
        APIHandler().getAPIValues(type: MedicalOffer.self, apiUrl: "\(ServiceAPI.medicalOffers)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.offers = data
                print(self.offers.data ?? "")
                print(self.offers.data?.count ?? 0)
                print(self.offers.data?.first?.refID ?? "")

                DispatchQueue.main.async {
                    UserDefaultsManager.shared.saveRefId(self.offers.data?.first?.refID ?? "")
                    self.RefID = UserDefaultsManager.shared.getUserRefId() ?? ""
                    self.emergencyTableView.reloadData()
                }
            case.failure(let error):
                print(error)
            }
        }
    }
    
    func GetMedicalReqAPI() {
//        APIHandler().getAPIValues(type: MedicalRequests.self, apiUrl: ServiceAPI.medicalRequests, method: "GET")
        APIHandler().getAPIValues(type: MedicalRequests.self, apiUrl: "\(ServiceAPI.medicalRequests)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.requests = data
                print(self.requests.data ?? "")
                print(self.requests.data?.count ?? 0)
                //print(self.requests.data?.first?.refID ?? "")
                
                DispatchQueue.main.async {
                    self.RefID = self.requests.data?.first?.refID ?? ""
                    UserDefaultsManager.shared.saveRefId(self.RefID)
                    
                    //UserDefaultsManager.shared.saveRefId(self.offers.data?.first?.refID ?? "")
                    self.emergencyTableView.reloadData()
                }
            case.failure(let error):
                print(error)
            }
        }
    }
}

extension EmergencyViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if nSelectedSegmentIndex == 1 {
            return self.offers?.data?.count ?? 1
        }
        else {
            return self.requests?.data?.count ?? 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EmergencyTableViewCell", for: indexPath) as! EmergencyTableViewCell
        
        cell.cellView.layer.cornerRadius = 10
        shadow.applyShadowView(to: cell.cellView)
        
        cell.acceptButton.tag = indexPath.row
        cell.acceptButton.addTarget(self, action: #selector(acceptOfferAPI), for: .touchUpInside)
        
        cell.reviewButtton.tag = indexPath.row
        cell.reviewButtton.addTarget(self, action: #selector(reviewAction), for: .touchUpInside)
        
        //cell.deleteButton.titleLabel?.font = .systemFont(ofSize: 12)
        
        if nSelectedSegmentIndex == 1 {
            if let offer = self.offers?.data?[indexPath.row] {
                cell.infoLabel.text = "\(offer.userID ?? "") : \(offer.category ?? "")\n\(offer.details ?? "")"
            } else {
                cell.infoLabel.text = "No Data"
            }
        } else if nSelectedSegmentIndex == 2{
            if let request = self.requests?.data?[indexPath.row] {
                cell.infoLabel.text = "\(request.userID ?? "") : \(request.category ?? "")\n\(request.details ?? "")"
            } else {
                cell.infoLabel.text = "No Data"
            }
        }
        
        return cell
    }
    
    @objc func reviewAction(sender: UIButton){
        let rowToRemove = sender.tag
        var refID: String? // Initialize refID as an optional String
            
            if self.nSelectedSegmentIndex == 1 {
                // Check if there's an offerRefID at the specified rowToRemove
                if let offerRefID = self.offers?.data?[rowToRemove].userID {
                    refID = offerRefID
                    UserDefaultsManager.shared.saveUserId(refID ?? "")
                    let vc = UIStoryboard(name: "HomeStoryboard", bundle: nil).instantiateViewController(withIdentifier: "ViewReviewViewController") as! ViewReviewViewController
                    navigationController?.pushViewController(vc, animated: true)
                }
            } else if self.nSelectedSegmentIndex == 2 {
                // Check if there's a requestRefID at the specified rowToRemove
                if let requestRefID = self.requests?.data?[rowToRemove].userID {
                    refID = requestRefID
                    UserDefaultsManager.shared.saveUserId(refID ?? "")
                    let vc = UIStoryboard(name: "HomeStoryboard", bundle: nil).instantiateViewController(withIdentifier: "ViewReviewViewController") as! ViewReviewViewController
                    navigationController?.pushViewController(vc, animated: true)
                }
            }
            
            self.emergencyTableView.reloadData()
    }
    
    
    @objc func acceptOfferAPI(sender: UIButton) {
        let rowToRemove = sender.tag
        var refID: String? // Initialize refID as an optional String
            
            if self.nSelectedSegmentIndex == 1 {
                // Check if there's an offerRefID at the specified rowToRemove
                if let offerRefID = self.offers?.data?[rowToRemove].refID {
                    refID = offerRefID
                }
            } else if self.nSelectedSegmentIndex == 2 {
                // Check if there's a requestRefID at the specified rowToRemove
                if let requestRefID = self.requests?.data?[rowToRemove].refID {
                    refID = requestRefID
                }
            }
            
            guard let validRefID = refID else {
                // Ensure that a valid refID exists for the selected segment
                return
            }
            
            if self.nSelectedSegmentIndex == 1 {
                // Use the selected refID to find the index to remove from "offers" data
                if let indexToRemove = self.offers?.data?.firstIndex(where: { $0.refID == validRefID }) {
                    self.offers?.data?.remove(at: indexToRemove)
                }
            } else if self.nSelectedSegmentIndex == 2 {
                // Use the selected refID to find the index to remove from "requests" data
                if let indexToRemove = self.requests?.data?.firstIndex(where: { $0.refID == validRefID }) {
                    self.requests?.data?.remove(at: indexToRemove)
                }
            }
            
            self.emergencyTableView.reloadData()
            
        let formData: [String: String] = ["user_id": self.UserID, "id": validRefID]
        
        APIHandler().postAPIValues(type: AcceptModel.self, apiUrl: "\(ServiceAPI.acceptAPI)", method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status)")
                print("Message: \(response.message)")
                DispatchQueue.main.async {
                    self.GetMedicalAPI()
                    self.GetMedicalReqAPI()
                }
            case .failure(let error):
                print("Error: \(error)")
                // Handle error
            }
        }
    }
    
//    @objc func acceptOfferAPI() {
//
//        let formData: [String: String] = ["user_id": self.UserID,
//                                          "id" : self.RefID
//        ]
//
//        APIHandler().postAPIValues(type: AcceptModel.self, apiUrl: ServiceAPI.acceptAPI, method: "POST", formData: formData) { result in
//            switch result {
//            case .success(let response):
//                print("Status: \(response.status)")
//                print("Message: \(response.message)")
//                DispatchQueue.main.async {
//                    self.GetMedicalAPI()
//                    self.GetMedicalReqAPI()
//                    //self.emergencyTableView.reloadData()
//                }
//            case .failure(let error):
//                print("Error: \(error)")
//                // Handle error
//
//            }
//        }
//
//    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
}


