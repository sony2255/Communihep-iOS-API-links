//
//  AddServiceRequestViewController.swift
//  CommuniHelp
//
//  Created by SAIL on 18/10/23.
//

import UIKit

class AddServiceRequestViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var plumbingButton: UIButton!
    @IBOutlet weak var ElectricianButton: UIButton!
    @IBOutlet weak var CarpenterButtton: UIButton!
    @IBOutlet weak var houseKeepingButton: UIButton!
    @IBOutlet weak var othersButton: UIButton!
    @IBOutlet weak var descriptionTextView: UITextView!
    
    var offersList = [String]()
    var request: AddServiceReq!
    let userId : String = UserDefaultsManager.shared.getUserId() ?? ""
    var sender = UIButton().tag
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.topView.layer.cornerRadius = 35
        self.topView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        
        self.descriptionTextView.layer.shadowColor = UIColor.black.cgColor
        self.descriptionTextView.layer.shadowOpacity = 0.3
        self.descriptionTextView.layer.shadowOffset = CGSize.zero
        self.descriptionTextView.layer.shadowRadius = 6
        self.descriptionTextView.layer.masksToBounds = true
            
        shadow.vc3 = self
        shadow.radioButton(to: plumbingButton)
        shadow.radioButton(to: ElectricianButton)
        shadow.radioButton(to: CarpenterButtton)
        shadow.radioButton(to: houseKeepingButton)
        shadow.radioButton(to: othersButton)
        
        
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func requestAction(_ sender: Any) {
        requestAPI()
    }
    
    func requestAPI() {
        var formData: [String: String] = [
            "user_id": self.userId,
                "details": descriptionTextView.text ?? ""
            ]
        
//        if sender == 1 {
//            formData["category"] = "Clothes"
//        } else if sender == 2 {
//            formData["category"] = "Food Materials"
//        } else if sender == 3 {
//            formData["category"] = "Carpenter"
//        } else if sender == 4 {
//            formData["category"] = "Study Materials"
//        } else if sender == 5 {
//            formData["category"] = "Electrical Appliances"
//        } else if sender == 6 {
//            formData["category"] = "Others"
//        }
//
        switch sender {
        case 0:
            formData["category"] = "Plumbing"
        case 1:
            formData["category"] = "Electrician"
        case 2:
            formData["category"] = "Carpenter"
        case 3:
            formData["category"] = "House Keeping"
        case 4:
            formData["category"] = "Others"
        default:
            formData["category"] = ""
        }
        print(sender)
        
        APIHandler().postAPIValues(type: AddServiceReq.self, apiUrl: "\(ServiceAPI.addServiceRequest)", method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print("Status: \(response.status)")
                    print("Message: \(response.message)")
                    DispatchQueue.main.async {
                        AlertManager.showAutoDismissAlert(title: "Services Request", message: "Added SuccessFully", viewController: self, navigationController: self.navigationController!, duration: 2.0)
                    }
                case .failure(let error):
                    print("Error: \(error)")
                }
            }
        }
}
