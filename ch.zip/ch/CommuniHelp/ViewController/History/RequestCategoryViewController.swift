//
//  RequestCategoryViewController.swift
//  CommuniHelp
//
//  Created by SAIL on 13/10/23.
//

import UIKit

class RequestCategoryViewController: UIViewController {
    
    @IBOutlet weak var productButton: UIButton!
    @IBOutlet weak var MedicalButton: UIButton!
    @IBOutlet weak var serviceButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        shadow.applyShadowButton(to: productButton)
        shadow.applyShadowButton(to: MedicalButton)
        shadow.applyShadowButton(to: serviceButton)
    }

    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func productButtonAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "HomeStoryboard", bundle: nil).instantiateViewController(withIdentifier: "AddProductRequestViewController") as! AddProductRequestViewController
        navigationController?.pushViewController(storyboard, animated: true)
    }
    @IBAction func medicalButtonAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "HomeStoryboard", bundle: nil).instantiateViewController(withIdentifier: "AddMedicalRequestViewController") as! AddMedicalRequestViewController
        navigationController?.pushViewController(storyboard, animated: true)
    }
    @IBAction func ServiceButtonAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "HomeStoryboard", bundle: nil).instantiateViewController(withIdentifier: "AddServiceRequestViewController") as! AddServiceRequestViewController
        navigationController?.pushViewController(storyboard, animated: true)
    }
}
