//
//  AddMedicalOfferViewController.swift
//  CommuniHelp
//
//  Created by SAIL on 18/10/23.
//

import UIKit

class AddMedicalOfferViewController: UIViewController {

    @IBOutlet weak var topView: UIButton!
    @IBOutlet weak var bloodButton: UIButton!
    @IBOutlet weak var medicineButton: UIButton!
    @IBOutlet weak var othersButton: UIButton!
    @IBOutlet weak var descriptionTextView: UITextView!
    
    var offersList = [String]()
    var request: AddMedicaOff!
    let userId : String = UserDefaultsManager.shared.getUserId() ?? ""
    var sender = UIButton().tag
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.topView.layer.cornerRadius = 35
        self.topView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        
        self.descriptionTextView.layer.shadowColor = UIColor.black.cgColor
        self.descriptionTextView.layer.shadowOpacity = 0.3
        self.descriptionTextView.layer.shadowOffset = CGSize.zero
        self.descriptionTextView.layer.shadowRadius = 6
        self.descriptionTextView.layer.masksToBounds = true
        
        shadow.vc5 = self
        shadow.radioButton(to: bloodButton)
        shadow.radioButton(to: medicineButton)
        shadow.radioButton(to: othersButton)
        
    }
    

    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func offerButtonAction(_ sender: Any) {
        offerAPI()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func offerAPI() {
        var formData: [String: String] = [
            "user_id": self.userId,
                "details": descriptionTextView.text ?? ""
            ]
        
//        if sender == 1 {
//            formData["category"] = "Clothes"
//        } else if sender == 2 {
//            formData["category"] = "Food Materials"
//        } else if sender == 3 {
//            formData["category"] = "Carpenter"
//        } else if sender == 4 {
//            formData["category"] = "Study Materials"
//        } else if sender == 5 {
//            formData["category"] = "Electrical Appliances"
//        } else if sender == 6 {
//            formData["category"] = "Others"
//        }
//
        switch sender {
        case 0:
            formData["category"] = "Blood"
        case 1:
            formData["category"] = "Medicine"
        case 2:
            formData["category"] = "Others"
        default:
            formData["category"] = ""
        }
        print(sender)
        
        APIHandler().postAPIValues(type: AddMedicaOff.self, apiUrl:"\(ServiceAPI.addMedicalOffer)", method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print("Status: \(response.status)")
                    print("Message: \(response.message)")
                    DispatchQueue.main.async {
                        AlertManager.showAutoDismissAlert(title: "Medical Emergency Offer", message: "Added SuccessFully", viewController: self, navigationController: self.navigationController!, duration: 2.0)
                    }
                case .failure(let error):
                    print("Error: \(error)")
                }
            }
        }

}
