//
//  EditProfileViewController.swift
//  CommuniHelp
//
//  Created by Haris Madhavan on 11/09/23.
//

import UIKit

class EditProfileViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var addressTextField: UITextField!
    @IBOutlet weak var confirmButton: UIButton!
    
    let UserID : String = UserDefaultsManager.shared.getUserId() ?? ""
        
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.topView.layer.cornerRadius = 35
        self.topView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        
        shadow.applyShadowTextField(to: nameTextField)
        addLeftViewToTextField(nameTextField)
        configureTextField(nameTextField, placeholderText: "Name")
        
        shadow.applyShadowTextField(to: emailTextField)
        addLeftViewToTextField(emailTextField)
        configureTextField(emailTextField, placeholderText: "E Mail")
        
        shadow.applyShadowTextField(to: addressTextField)
        addLeftViewToTextField(addressTextField)
        configureTextField(addressTextField, placeholderText: "Phone Number")
        
        self.confirmButton.titleLabel?.font = .systemFont(ofSize: 20)
        
    }
    
    func isValidEmailAddress(emailAddressString: String) -> Bool {
        
        var returnValue = true
        let emailRegEx = "[A-Z0-9a-z.-_]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,3}"
        
        do {
            let regex = try NSRegularExpression(pattern: emailRegEx)
            let nsString = emailAddressString as NSString
            let results = regex.matches(in: emailAddressString, range: NSRange(location: 0, length: nsString.length))
            
            if results.count == 0
            {
                returnValue = false
            }
            
        } catch let error as NSError {
            print("invalid regex: \(error.localizedDescription)")
            returnValue = false
        }
        
        return  returnValue
    }
    
    //TextField_Padding
    func addLeftViewToTextField(_ textField: UITextField) {
        let leftView = UIView(frame: CGRect(x: 5, y: 5, width: 15, height: textField.frame.height))
        textField.leftView = leftView
        textField.leftViewMode = .always
    }
    
    //Placeholder_Text_Colour
    func configureTextField(_ textField: UITextField, placeholderText: String) {
        textField.delegate = self
        textField.attributedPlaceholder = NSAttributedString(
            string: placeholderText,
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.black]
        )
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func confirmButtonAction(_ sender: Any) {
        if nameTextField.text == "" && emailTextField.text == "" && addressTextField.text == "" {
            AlertManager.showAlert(title: "Field is Empty", message: "Please enter the value", viewController: self) {
                self.navigationController?.popViewController(animated: true)
            }
        } else if isValidEmailAddress(emailAddressString: emailTextField.text ?? "") != true{
            AlertManager.showAlert(title: "Invalid Email", message: "Please enter valid Email", viewController: self)
        } else {
            EditProfileAPI()
        }
    }
    
    func EditProfileAPI() {
            let formData: [String: String] = [
                "username": nameTextField.text ?? "",
                "email": emailTextField.text ?? "",
                "phone_number": addressTextField.text ?? "",
                "user_id": self.UserID
            ]
        APIHandler().postAPIValues(type: editProfileModel.self, apiUrl:"\(ServiceAPI.editProfile)", method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print("Status: \(response.status)")
                    print("Message: \(response.message)")
                    DispatchQueue.main.async {
                        AlertManager.showAlert(title: "Success", message: "Your profile edited successfully!", viewController: self) {
                            self.navigationController?.popViewController(animated: true)
                        }
                    }
                case .failure(let error):
                    print("Error: \(error)")
                    DispatchQueue.main.async {
                        AlertManager.showAlert(title: "Failure", message: "Something went wrong", viewController: self) {
                            self.navigationController?.popViewController(animated: true)
                        }
                    }
                }
            }
        }
}
