//
//  AccountViewController.swift
//  CommuniHelp
//
//  Created by Haris Madhavan on 10/09/23.
//

import UIKit

class AccountViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var editButton: UIButton!
    @IBOutlet weak var ChangePwButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.topView.layer.cornerRadius = 35
        self.topView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        
        shadow.applyShadowButton(to: editButton)
        shadow.applyShadowButton(to: ChangePwButton)
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        for controller in self.navigationController!.viewControllers as Array {
            if controller.isKind(of: SettingViewController.self) {
                self.navigationController!.popToViewController(controller, animated: true)
                break
            }
        }
    }
    
    @IBAction func editButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "EditProfileViewController") as! EditProfileViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func changePwButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "ChangePWViewController") as! ChangePWViewController
        navigationController?.pushViewController(vc, animated: true)
    }
}
