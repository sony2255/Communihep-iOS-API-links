//
//  ChangePWViewController.swift
//  CommuniHelp
//
//  Created by Haris Madhavan on 09/09/23.
//

import UIKit

class ChangePWViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var oldPwTextField: UITextField!
    @IBOutlet weak var newPwTextField: UITextField!
    @IBOutlet weak var confirmPwTextField: UITextField!
    @IBOutlet weak var confirmButton: UIButton!
    
    let UserID : String = UserDefaultsManager.shared.getUserId() ?? ""
    let Password : String = UserDefaultsManager.shared.getUserPassword() ?? ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.topView.layer.cornerRadius = 35
        self.topView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        
        shadow.applyShadowTextField(to: oldPwTextField)
        addLeftViewToTextField(oldPwTextField)
        configureTextField(oldPwTextField, placeholderText: "Old password")
        
        shadow.applyShadowTextField(to: newPwTextField)
        addLeftViewToTextField(newPwTextField)
        configureTextField(newPwTextField, placeholderText: "New password")
        newPwTextField.isSecureTextEntry = true
        
        shadow.applyShadowTextField(to: confirmPwTextField)
        addLeftViewToTextField(confirmPwTextField)
        configureTextField(confirmPwTextField, placeholderText: "Confirm password")
        confirmPwTextField.isSecureTextEntry = true
        
        self.confirmButton.titleLabel?.font = .systemFont(ofSize: 20)
    }
    
    //TextField_Padding
    func addLeftViewToTextField(_ textField: UITextField) {
        let leftView = UIView(frame: CGRect(x: 5, y: 5, width: 15, height: textField.frame.height))
        textField.leftView = leftView
        textField.leftViewMode = .always
    }
    
    //Placeholder_Text_Colour
    func configureTextField(_ textField: UITextField, placeholderText: String) {
        textField.delegate = self
        textField.attributedPlaceholder = NSAttributedString(
            string: placeholderText,
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.black]
        )
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func confirmButtonAction(_ sender: Any) {
        if oldPwTextField.text?.isEmpty == true && newPwTextField.text?.isEmpty == true {
            AlertManager.showAlert(title: "Field is Empty", message: "Please enter all the value", viewController: self)
        } else if oldPwTextField.text != UserDefaultsManager.shared.getUserPassword() {
            AlertManager.showAlert(title: "Enter valid password", message: "Please enter valid old password", viewController: self)
        } else if newPwTextField.text != confirmPwTextField.text {
            AlertManager.showAlert(title: "Invalid", message: "New password and confirm password is not equal", viewController: self)
        } else {
            ChangePassAPI()
        }
    }
    
    func ChangePassAPI() {
        let formData: [String: String] = [
            "oldpass": oldPwTextField.text ?? "",
            "newpass": newPwTextField.text ?? "",
            "user_id": self.UserID
        ]
        APIHandler().postAPIValues(type: changePass.self, apiUrl: "\(ServiceAPI.changePass)", method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status)")
                print("Message: \(response.message)")
                DispatchQueue.main.async {
                    AlertManager.showAlert(title: "Success", message: "Your password updated Successfully", viewController: self) {
                        self.navigationController?.popViewController(animated: true)
                    }
                }
            case .failure(let error):
                print("Error: \(error)")
                DispatchQueue.main.async {
                    AlertManager.showAlert(title: "Failure", message: "Something went wrong", viewController: self) {
                        self.navigationController?.popViewController(animated: true)
                    }
                }
            }
        }
    }
    
}
