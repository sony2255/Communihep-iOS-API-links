//
//  LoginViewController.swift
//  CommuniHelp
//
//  Created by Haris Madhavan on 09/09/23.
//

import UIKit

class LoginViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var eMailTextField: UITextField!
    @IBOutlet weak var PasswordTextField: UITextField!
    @IBOutlet weak var ForgetPwButton: UIButton!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var helpView: UIView!
    
    var login: LoginJSON!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.topView.layer.cornerRadius = 35
        self.topView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        
        self.eMailTextField.layer.cornerRadius = 10
        addLeftViewToTextField(eMailTextField)
        configureTextField(eMailTextField, placeholderText: "E MAIL")
        
        self.PasswordTextField.layer.cornerRadius = 10
        addLeftViewToTextField(PasswordTextField)
        configureTextField(PasswordTextField, placeholderText: "PASSWORD")
        self.PasswordTextField.isSecureTextEntry = true
        
        self.loginButton.titleLabel?.font = .systemFont(ofSize: 20)
        
        shadow.applyShadowView(to: helpView)
        
        helpView.isHidden = true
        
        let tap = UITapGestureRecognizer()
        tap.addTarget(self, action: #selector(tapAction))
        view.addGestureRecognizer(tap)
    }
    
    @objc func tapAction() {
        helpView.isHidden = true
    }
    
    func isValidEmailAddress(emailAddressString: String) -> Bool {
        
        var returnValue = true
        let emailRegEx = "[A-Z0-9a-z.-_]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,3}"
        
        do {
            let regex = try NSRegularExpression(pattern: emailRegEx)
            let nsString = emailAddressString as NSString
            let results = regex.matches(in: emailAddressString, range: NSRange(location: 0, length: nsString.length))
            
            if results.count == 0
            {
                returnValue = false
            }
            
        } catch let error as NSError {
            print("invalid regex: \(error.localizedDescription)")
            returnValue = false
        }
        
        return  returnValue
    }
    
    //TextField_Padding
    func addLeftViewToTextField(_ textField: UITextField) {
        let leftView = UIView(frame: CGRect(x: 5, y: 5, width: 15, height: textField.frame.height))
        textField.leftView = leftView
        textField.leftViewMode = .always
    }
    
    //Placeholder_Text_Colour
    func configureTextField(_ textField: UITextField, placeholderText: String) {
        textField.delegate = self
        textField.attributedPlaceholder = NSAttributedString(
            string: placeholderText,
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.black]
        )
    }
    
    @IBAction func backbuttonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func forgetPwAction(_ sender: Any) {
        helpView.isHidden = false
    }
    
    @IBAction func loginAction(_ sender: Any) {
        
        if eMailTextField.text == "" && PasswordTextField.text == "" {
            let alert = UIAlertController(title: "Field is Empty", message: "Please enter the values", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true)
        } else if isValidEmailAddress(emailAddressString: eMailTextField.text ?? "") == true {
            getLoginAPI()
        } else {
            AlertManager.showAlert(title: "Invalid", message: "Enter Valid Email Address", viewController: self)
        }
        
        //        let storyboard = UIStoryboard(name: "HomeStoryboard", bundle: nil)
        //        let vc = storyboard.instantiateViewController(withIdentifier: "InitialTabBarController") as! InitialTabBarController
        //        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    func getLoginAPI(){
        
        APIHandler().getAPIValues(type: LoginJSON.self, apiUrl: "\(ServiceAPI.loginURl)&email=\(eMailTextField.text ?? "")&pass=\(PasswordTextField.text ?? "")", method: "GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.login = data
                DispatchQueue.main.async {
                    UserDefaultsManager.shared.saveUserId(self.login.data?.userID ?? "")
                    UserDefaultsManager.shared.saveUserPassword(self.login.data?.pass ?? "")
                    if self.eMailTextField.text != self.login.data?.email && self.PasswordTextField.text != self.login.data?.pass {
                        let alert = UIAlertController(title: "Warning", message: "Incorrect ID or Password", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                        self.present(alert, animated: true)
                    } else {
                        let storyboard = UIStoryboard(name: "HomeStoryboard", bundle: nil)
                        let vc = storyboard.instantiateViewController(withIdentifier: "InitialTabBarController") as! InitialTabBarController
                        self.navigationController?.pushViewController(vc, animated: true)
                    }
                    
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    //                    let alert = UIAlertController(title: "Warning", message: "Incorrect ID or Password", preferredStyle: .alert)
                    //                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    //                    self.present(alert, animated: true)
                }
                
            }
        }
    }
    
}
