//
//  ViewReviewViewController.swift
//  CommuniHelp
//
//  Created by SAIL on 16/11/23.
//

import UIKit

class ViewReviewViewController: UIViewController {
    
    @IBOutlet weak var viewReviewTableView: UITableView!
    @IBOutlet weak var topView: UIView!
    
    var userid = UserDefaultsManager.shared.getUserId() ?? ""
    var rev: viewReviewModel!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.viewReviewTableView.delegate = self
        self.viewReviewTableView.dataSource = self
        
        self.topView.layer.cornerRadius = 35
        self.topView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
    }
    
    override func viewWillAppear(_ animated: Bool) {
        GetReview()
    }
    
    @IBAction func backActionButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    func GetReview() {
//        APIHandler().getAPIValues(type: viewReviewModel.self, apiUrl: ServiceAPI.viewReview, method: "GET")
        APIHandler().getAPIValues(type: viewReviewModel.self, apiUrl: "\(ServiceAPI.viewReview)user_id=\(userid)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.rev = data
                print(self.rev.data ?? "")
                print(self.rev.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.viewReviewTableView.reloadData()
                }
            case.failure(let error):
                print(error)
            }
        }
    }
    

}

extension ViewReviewViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.rev?.data?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ViewReviewTableViewCell", for: indexPath) as! ViewReviewTableViewCell
        
        cell.cellView.layer.cornerRadius = 10
        shadow.applyShadowView(to: cell.cellView)
        
        if let offer = self.rev?.data?[indexPath.row] {
            cell.infoLabel.text = "\(offer.userID ?? "") : \(offer.category ?? "")\n\(offer.details ?? "")"
            cell.reviewLabel.text = "Review: \(offer.review ?? "")"
        } else {
            cell.infoLabel.text = "No Data"
            cell.reviewLabel.text = ""
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
}
