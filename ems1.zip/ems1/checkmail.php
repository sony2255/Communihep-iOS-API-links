<?php
require_once('dbh.php');

$loginqry = "SELECT email FROM `sign_up`";

$qry = mysqli_query($dbconn, $loginqry);

if(mysqli_num_rows($qry) > 0){
	
	$i =0;
	while($row = mysqli_fetch_assoc($qry)){
	$student[$i]['email'] = $row['email'];
	$i = $i+1;
	}
	$response['status'] = true;
	$response['message']= "email";
	$response['data'] = $student;	
}
else{  
	$response['status'] = false;
	$response['message']= "No Data";	
}
// if(mysqli_num_rows($qry) > 0){
	
// 	$userObj = mysqli_fetch_assoc($qry); 
// 	$response['status'] = true;
// 	$response['message']= "Checked Successfully";
// 	$response['data'] = $userObj;	
// }
// else{
// 	$response['status'] = false;
// 	$response['message']= "Check Failed";	
// }
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>


