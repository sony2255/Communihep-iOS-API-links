<?php

include 'dbh.php';

$user_id =$_GET['user_id'];

$loginqry = "SELECT * FROM sign_up WHERE user_id = '$user_id'";
$qry = mysqli_query($dbconn, $loginqry);
if(mysqli_num_rows($qry) > 0){
$userObj = mysqli_fetch_assoc($qry);
$response['status'] = true;
$response['message']= "Profile";
$response['data'] = $userObj;
}
else{
$response['status'] = false;
$response['message']= "No Data";
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>

