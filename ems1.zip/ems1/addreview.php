<?php

include 'dbh.php';
$user_id =$_POST['user_id'];
$ref_id =$_POST['ref_id'];
$category =$_POST['category'];
$details =$_POST['details'];
$review = $_POST['review'];

$loginqry = "INSERT INTO reviews(ref_id, category, details, user_id, review)VALUES('$ref_id', '$category', '$details', '$user_id', '$review')";

$res = mysqli_query($dbconn, $loginqry);

if($res){

$response['status'] = true;
$response['message']= " Added review Successfully";

}
else{
$response['status'] = false;
$response['message']= "Add review Failed";
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>


