<?php

include 'dbh.php';
$user_id =$_POST['user_id'];
$username =$_POST['username'];
$phone_number =$_POST['phone_number'];
$email = $_POST['email'];

//$loginqry = "INSERT INTO sign_up(username,email,phone_number, pass )VALUES('$username','$email','$phone_number','$pass')";
$loginqry = "UPDATE `sign_up` SET `username`='$username',`email`='$email',`phone_number`='$phone_number' WHERE `user_id`='$user_id'";

$res = mysqli_query($dbconn, $loginqry);

if($res){

$response['status'] = true;
$response['message']= " Updated Successfully";

}
else{
$response['status'] = false;
$response['message']= "Updated Failed";
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>



