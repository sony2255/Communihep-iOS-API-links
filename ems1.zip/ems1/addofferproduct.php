<?php

include 'dbh.php';
$offerrequest='offer';
$type='products';
$user_id =$_POST['user_id'];
$category =$_POST['category'];
$details = $_POST['details'];

$loginqry = "INSERT INTO offer_request(user_id,offerrequest,type,category,details )VALUES('$user_id','$offerrequest','$type','$category','$details')";

$res = mysqli_query($dbconn, $loginqry);

if($res){

$response['status'] = true;
$response['message']= " Add Product Offer Successfully";

}
else{
$response['status'] = false;
$response['message']= "Add Product Offer Failed";
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>


