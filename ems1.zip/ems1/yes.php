<?php

include 'dbh.php';
$ref_id=$_POST['ref_id'];
$acc='1';

$loginqry = "UPDATE offer_request SET yesno='$acc' WHERE ref_id='$ref_id'";

$res = mysqli_query($dbconn, $loginqry);

if($res){

$response['status'] = true;
$response['message']= " Proceed Offer Successfully";

}
else{
$response['status'] = false;
$response['message']= "Proceed Offer Failed";
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
