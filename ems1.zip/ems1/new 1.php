<?php //error_reporting(0); ?> 
<!-- <?php

include 'dbh.php';
$username =$_POST['username'];
$phone_number =$_POST['phone_number'];
$email = $_POST['email'];
$pass =$_POST['pass']; 
//$_POST['bioid'];
//$password ='pass123';
//echo  $bioid. $password;   //$_POST['password'];
//$loginqry = "SELECT * FROM sign_up WHERE user_id = '$bioid'";
//$loginqry = "SELECT * FROM users WHERE bioid = 10101 AND password ='pass123'";
$loginqry = "INSERT INTO sign_up(username,email,phone_number, pass )VALUES('$username','$email','$phone_number','$pass')";

$qry = mysqli_query($conn, $loginqry);
if(mysqli_num_rows($qry) > 0){
$userObj = mysqli_fetch_assoc($qry);
$response['status'] = true;
$response['message']= " Login Successfully";
$response['data'] = $userObj;
}
else{
$response['status'] = false;
$response['message']= "Login Failed";
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
//http://172.18.26.44/ems1/index.php?email=mainareddy25@outlook.com&pass=123
?> -->



