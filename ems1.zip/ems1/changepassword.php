<?php

include 'dbh.php';
$user_id =$_POST['user_id'];
$oldpass =$_POST['oldpass'];
$newpass =$_POST['newpass'];
//$conpass =$_POST['conpass']

$loginqry = "UPDATE `sign_up` SET pass='$newpass' WHERE user_id='$user_id' and pass='$oldpass'";

$res = mysqli_query($dbconn, $loginqry);

if($res){

$response['status'] = true;
$response['message']= " pass Updated Successfully";

}
else{
$response['status'] = false;
$response['message']= "pass Updated Failed";
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>



