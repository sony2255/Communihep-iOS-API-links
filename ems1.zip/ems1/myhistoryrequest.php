<?php
require_once('dbh.php');

$user_id=$_GET['user_id'];

$loginqry = "SELECT ref_id, user_id, category, details FROM offer_request WHERE user_id = '$user_id' AND offerrequest = 'request'";

$qry = mysqli_query($dbconn, $loginqry);

if(mysqli_num_rows($qry) > 0){
	
	$i =0;
	while($row = mysqli_fetch_assoc($qry)){
	$student[$i]['ref_id'] = $row['ref_id'];
	$student[$i]['user_id'] = $row['user_id'];
	$student[$i]['category'] = $row['category'];
	$student[$i]['details'] = $row['details'];
	
	
	$i = $i+1;
	}
	$response['status'] = true;
	$response['message']= "My History Requests";
	$response['data'] = $student;	
}
else{
	$response['status'] = false;
	$response['message']= "No Data";	
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>