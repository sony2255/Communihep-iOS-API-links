<?php

include 'dbh.php';
$ref_id=$_POST['id'];
$acc='0';

$loginqry = "UPDATE offer_request SET accept_status=$acc, accept_user_id='' WHERE ref_id=$ref_id";

$res = mysqli_query($dbconn, $loginqry);

if($res){

$response['status'] = true;
$response['message']= " Ignored Offer Successfully";

}
else{
$response['status'] = false;
$response['message']= "Ignored Offer Failed";
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
