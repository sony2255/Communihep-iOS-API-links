<?php
require_once('dbh.php');

$user_id =$_GET['user_id'];

$loginqry1="SELECT * FROM offer_request
INNER JOIN sign_up ON offer_request.user_id = sign_up.user_id
WHERE offer_request.accept_user_id ='$user_id' AND offer_request.yesno ='1'";

$qry1 = mysqli_query($dbconn, $loginqry1);

if(mysqli_num_rows($qry1) > 0){
	
	$i =0;
	while($row1 = mysqli_fetch_assoc($qry1)){
	$student[$i]['ref_id'] = $row1['ref_id'];
	$student[$i]['user_id'] = $row1['user_id'];
	$student[$i]['category'] = $row1['category'];
	$student[$i]['details'] = $row1['details'];
    $student[$i]['phone_number'] = $row1['phone_number'];
	
	$i = $i+1;
	}

	$response['status'] = true;
	$response['message']= "Notification 1";
	$response['data'] = $student;	
}
else{
	$response['status'] = false;
	$response['message']= "No Data";	
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>