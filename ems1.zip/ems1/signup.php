<?php

include 'dbh.php';

$username =$_POST['username'];
$email = $_POST['email'];
$phone_number =$_POST['phone_number'];
$pass =$_POST['pass']; 
//$conpass=$_POST['conpass']

$loginqry = "INSERT INTO sign_up(username,email,phone_number,pass)VALUES('$username','$email','$phone_number','$pass')";

$res = mysqli_query($dbconn, $loginqry);

if($res){

$response['status'] = true;
$response['message']= " Signup Successfully";

}
else{
$response['status'] = false;
$response['message']= "Signup Failed";
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>



