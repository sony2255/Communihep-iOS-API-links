<?php

include 'dbh.php';
$id=$_POST['id'];
$user_id =$_POST['user_id'];
$acc='1';

$loginqry = "UPDATE offer_request SET accept_status= $acc, accept_user_id=$user_id WHERE ref_id=$id";

$res = mysqli_query($dbconn, $loginqry);

if($res){

$response['status'] = true;
$response['message']= " Accepted Medical Emergency Request Successfully";

}
else{
$response['status'] = false;
$response['message']= "Accepted Medical Emergency Request Failed";
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
